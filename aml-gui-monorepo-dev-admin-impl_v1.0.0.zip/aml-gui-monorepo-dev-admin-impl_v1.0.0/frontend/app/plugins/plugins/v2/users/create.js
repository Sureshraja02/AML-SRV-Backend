import { Col, PageCenterLayout, Row } from '@ais/components';
import RenderForm from 'RenderForm';
import api from 'api';
import generateQueryFromFormJson from 'generateQueryFromFormJson';
import React, { useState } from 'react';
import useRoleBasedNavigate from 'useRoleBasedNavigate';
import userCreation from '../../../json/userRegistration.json';

function CreateUser({ id }) {
  const [formData, SetFormData] = useState([]);
  const [error, seterror] = useState(null);
  const [loading, setloading] = useState(false);
  const { roleBasedNavigate } = useRoleBasedNavigate();

  const args = {
    username: true,
    firstName: true,
    lastName: true,
    email: true,
    bankName: true,
    insId: true,
    role: true,
    password: true,
  };

  const callback = (values, actions) => {
    setloading(true);
    const gqlQuery = generateQueryFromFormJson(userCreation, args, true);
    console.log(gqlQuery);
    console.log(values);
    api.graphql(gqlQuery, values).then((res) => {
      const { loading, data, error } = res;

      seterror(error);
      setloading(loading);

      if (data)
        roleBasedNavigate('1101', true, {
          state: {
            status: 'success',
            message: 'Record inserted or updated successfully',
          },
        });
      //have to check how to route success
    });

    //create account first but api not available
    // var data = {
    //   email,
    //   instId,
    //   mobileNo: phoneNo,
    //   password,
    //   userName: email,
    //   userType: "admin",
    // };
    // sendData.post("/app/rest/v1.0/save/user", values).then((d) => {
    //   console.log(d);
    // });
  };

  React.useEffect(() => {
    console.debug('id to load : ' + id);
    // loadData.get("/app/rest/v1.0/fetch/user/" + id, {}).then((res) => {
    //   SetFormData(res);
    // });
  }, [id]);

  return (
    <>
      <>
        <PageCenterLayout size={`na`}>
          <Row>
            <Col>
              <RenderForm
                formFormat={userCreation}
                error={error}
                loading={loading}
                formData
                callback={callback}
              />
            </Col>
          </Row>
        </PageCenterLayout>
      </>
    </>
  );
}

export default CreateUser;
