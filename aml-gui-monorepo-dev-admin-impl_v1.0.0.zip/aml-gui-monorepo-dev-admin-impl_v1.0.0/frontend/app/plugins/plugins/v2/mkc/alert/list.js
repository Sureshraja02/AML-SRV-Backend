import api from '@ais/api';
import {
  Button,
  H1,
  H3,
  IconButton,
  LoadingComponent,
  MutedBgLayout,
  PageCenterLayout,
  SimpleCard
} from '@ais/components';
import { SimpleTable } from '@ais/datatable';
import { jsonToGraphQLQuery } from '@ais/graphql';
import React, { useEffect, useState } from 'react';
import useModalHost from 'useModalHost';
import useRoleBasedNavigate from 'useRoleBasedNavigate';


function AlertList() {
  const [loading, setloading] = React.useState();
  const [showModal, setshowModal] = useState(false);
  const [tableData, settableData] = useState([]);


  const { showPluginModal } = useModalHost();

  const { roleBasedNavigate } = useRoleBasedNavigate();

  const data = [
    {
      id: '100',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'LOW',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '101',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'LOW',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '102',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'LOW',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '103',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'LOW',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '104',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'LOW',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '105',
      category: 'CounterFeit Txn',
      status: 'unAssinged',
      priority: 'HIGH',
      assingedTo: '',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 10:00 AM',
    },
    {
      id: '106',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'MEDIUM',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
    {
      id: '107',
      category: 'Suspicious Txn',
      status: 'Open',
      priority: 'MEDIUM',
      assingedTo: 'John',
      createdAt: '10-May-25 12:00 AM',
      updatedAt: '11-May-25 09:00 AM',
    },
  ];

  const columns = {
    instanceId: {
      show: false
    },
    entityId: {
      show: false
    },
    parentId: {
      label: "Alert ID"
    },
    customerId: {
      label: "Customer Id"
    },
    alertId: {
      label: "Alert Count",
      render: (row) => <><Button label={row.alertId} variant='link' onClick={() => roleBasedNavigate('/mkc/alert/view', true, { size: 'pg', ...row })}>
      </Button></>
    },
    customerAccountType: {
      show: false
    },
    comments: {
      show: false
    },
    approved: {
      show: false
    },
    actions: {
      label: 'Actions',
      render: (row) => (
        <IconButton
          icon={'Eye'}
          size={20}
          className={`cursor-pointer`}
          onClick={() => roleBasedNavigate('/mkc/alert/view', true, { size: 'pg', ...row })}
        ></IconButton>
      ),
    },
  };


  useEffect(() => {
    setloading(true);

    const gjson = {
      query: {
        findEntitiesPendingForApproval: {
          entityId: true,
          entityType: true,
          currentLevel: true,
          status: true,
          id: true,
          pendingData: {
            payload: true
          }
        }
      }
    }

    const graphqlQuery = jsonToGraphQLQuery(gjson);

    api.graphql(graphqlQuery).then((res) => {
      const { loading, error, data } = res;
      setloading(loading);
      if (data && "findEntitiesPendingForApproval" in data) {
        console.log(data['findEntitiesPendingForApproval']);
        data['findEntitiesPendingForApproval'].forEach(item => {
          const pendingString = item['pendingData']['payload'];
          console.log(pendingString);
          if (pendingString) {
            let pendingData = JSON.parse(pendingString);
            pendingData['instanceId'] = item.id;
            pendingData['entityId'] = item.entityId;
            console.log(pendingData);
            settableData(prev => [...prev, pendingData]);
          }
        })
      }
    });


  }, []);


  useEffect(() => {
    console.log(tableData);
  }, [tableData]);



  if (loading) return <PageCenterLayout><LoadingComponent></LoadingComponent></PageCenterLayout>

  return (
    <>
      <MutedBgLayout>
        <H1>Alert List</H1>
        <SimpleCard>
          {tableData.length > 0 ? (
            <SimpleTable data={tableData} columns={columns}></SimpleTable>
          ) : <H3><div className={`text-center`}>
            No data available to authorize
          </div>
          </H3>}
        </SimpleCard>

        {/* <SimpleModal
          isOpen={showModal}
          handleClose={() => setshowModal(false)}
          title={`Alert Details : 100`}
          size="pg"
        >
          <AlertView />
        </SimpleModal> */}
      </MutedBgLayout>
    </>
  );
}

export default AlertList;
