/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/rules-of-hooks */

import api from '@ais/api';
import { Avatar, AvatarFallback, AvatarImage, Col, Heading, InfoItem, NGPLine, Row, Separator, SimpleCard, Subheading, TableLayout } from '@ais/components';
import { SimpleTable } from '@ais/datatable';
import { jsonToGraphQLQuery, VariableType } from '@ais/graphql';
import { flattenArray, groupby } from '@ais/utils';
import React, { useEffect, useState } from 'react';

function ViewCustomers({ isTxn = false }) {
  const [data, setdata] = React.useState(true);

  const [loading, setloading] = useState(false);
  const [error, seterror] = useState(false);
  const [initalValues, setinitalValues] = useState([]);

  // const [formValues, setformValues] = useState(initalValues);

  const loadData = () => {
    setloading(true);
    let graph = {
      query: {
        __variables: {
          type: 'String!',
        },
        listEventsEntity: {
          eventName: true,
          id: true,
        },
        findEventMetaByMetaType: {
          __args: {
            metaType: new VariableType('type'),
          },
          metaName: true,
          metaValue: true,
          id: true,
          event: {
            id: true,
          },
        },
      },
    };

    const gql = jsonToGraphQLQuery(graph);
    console.log(gql);
    api.graphql(gql, { type: 'challenge' }).then((res) => {
      const { loading, data, error } = res;

      setloading(loading);
      seterror(error);
      console.log(res);
      if (data) {
        let dta = data.listEventsEntity;
        const flatternedArray = flattenArray(data.findEventMetaByMetaType);
        let values = groupby(flatternedArray, 'event.id');

        if (Array.isArray(dta) && dta.length > 0) {
          const arr = dta.map((dt, index) => {
            const jJson = {};
            console.log(dt.id);
            if (dt.id in values) {
              const sortedArray = values[dt.id];
              if (Array.isArray(sortedArray)) {
                const d = sortedArray.map((ddata) => {
                  return (jJson[ddata['metaName']] = JSON.parse(
                    ddata['metaValue'],
                  ));
                });
              }
            }

            return {
              name: dt.eventName,
              value: dt.eventName,
              id: dt.id,
            };
          });

          setinitalValues(arr);
        }
      }
    });

    setloading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const custDetails = {
    Address: 'XXXXXX31',
    'Home branch': 'Branch 1',
    'Phone number': 'John Doe',
    Email: 'UNVERIFED',
  };

  const behaviourDetails = {
    'Unusual Login frequency': false,
    'Login from unfamiler IP': false,
    'Unusual Large amount transfer': true,
    'New beneficiary followed by large Transaction': true,
    'Frequent re-install of mobile app': true,
  };

  const auditLog = [
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'LOGIN',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'NEFT',
      'transaction At': '12/04/25 1:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'VIEW-BALANCE',
      'transaction At': '12/04/25 2:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'ADD BENEFICIARY',
      'transaction At': '12/04/25 2:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'NEFT',
      'transaction At': '12/04/25 2:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
    {
      deviceID: '12345ASASGDGGDS123',
      transactionType: 'APP-REGISTER',
      'transaction At': '12/04/25 12:00:00PM',
    },
  ];

  const TxnHistoryStructure = {
    queryType: 'listEvents',
    columns: [
      { key: 'id', label: 'ID', type: 'UUID', show: false },
      { key: 'eventName', label: 'Name', type: 'text' },
      { key: 'createdAt', label: 'Created', type: 'date' },
    ],
  };

  const monthlyTxns = [
    { date: 'Jan', count: 10 },
    { date: 'Feb', count: 25 },
    { date: 'Mar', count: 40 },
    { date: 'Apr', count: 301 },
    { date: 'Jun', count: 130 },
    { date: 'Jul', count: 245 },
    { date: 'Aug', count: 470 },
    { date: 'Sep', count: 360 },
    { date: 'Oct', count: 150 },
    { date: 'Nov', count: 245 },
    { date: 'Dec', count: 430 },
  ];

  return (
    <TableLayout>
      <Row>
        <Col span='12'>
          <Heading
            title={`View ${isTxn ? 'Transaction Details' : 'Customer'}`}
          // subTitle="Define the rule and then review it"
          />
        </Col>
        <Col span='12'>
          <Row gap={0}>
            <Col span="6">
              <SimpleCard gap={0}>
                <Row align="center">
                  <Col padding={false} span="auto">
                    <Avatar size={16}>
                      <AvatarImage src={''} alt={'Customer'} />
                      <AvatarFallback size={'2xl'}>CS</AvatarFallback>
                    </Avatar>
                  </Col>
                  <Col padding={false} span="3" md={3} lg={3} sm={3}>
                    <InfoItem title={'Name'} className={'mb-2'}>
                      <span>Demo 123</span>
                    </InfoItem>
                  </Col>
                  <Col padding={false} span="3" md={3} lg={3} sm={3}>
                    <InfoItem title={'Date of Birth'} className={'mb-2'}>
                      <span>10/10/2010</span>
                    </InfoItem>
                  </Col>
                  <Col padding={false} span="3" md={3} lg={3} sm={3}>
                    <InfoItem title={'KYC Status'} className={'mb-2'}>
                      <span className="text-warning">un-verified</span>
                    </InfoItem>
                  </Col>
                </Row>

                <Subheading className={'text-primary'} title={`Contact`}>
                  <Row gap={0}>
                    {Object.keys(custDetails).map((cust, index) => {
                      return (
                        <Col gap={1} span="3" sm={3} md={3} lg={3}>
                          <InfoItem title={cust} className={'mb-2'}>
                            <span>{custDetails[cust]}</span>
                          </InfoItem>
                        </Col>
                      );
                    })}
                    <Separator className={'mb-6'} />
                  </Row>
                </Subheading>
                <Subheading className={'text-primary'} title={`Nominee`}>
                  <Row gap={0}>
                    {Object.keys(custDetails).map((cust, index) => {
                      return (
                        <Col gap={1} span="3" sm={3} md={3} lg={3}>
                          <InfoItem title={cust} className={'mb-2'}>
                            <span>{custDetails[cust]}</span>
                          </InfoItem>
                        </Col>
                      );
                    })}
                    <Separator className={'mb-6'} />
                  </Row>
                </Subheading>
                <Subheading className={'text-primary'} title={`Others`}>
                  <Row gap={0}>
                    {Object.keys(custDetails).map((cust, index) => {
                      return (
                        <Col gap={1} span="3" sm={3} md={3} lg={3}>
                          <InfoItem title={cust} className={'mb-2'}>
                            <span>{custDetails[cust]}</span>
                          </InfoItem>
                        </Col>
                      );
                    })}
                  </Row>
                </Subheading>
              </SimpleCard>
            </Col>

            <Col span="6">
              <SimpleCard align="left" title={'Account Activity'}>
                <Row gap="2" direction='col'>
                  <Col span="auto" className={'gap-3 flex mb-6'}>
                    <InfoItem title={'Account number'} className={'mb-2'}>
                      <span>12312345667</span>
                    </InfoItem>
                    <InfoItem title={'Instituion'} className={'mb-2'}>
                      <span>{'112'}</span>
                    </InfoItem>
                    <InfoItem title={'Account Type'} className={'mb-2'}>
                      <span>{'Savings'}</span>
                    </InfoItem>
                  </Col>
                </Row>
                <Row>
                  <NGPLine
                    lineData={monthlyTxns}
                    dataKey={'date'}
                    dataValue={'count'}
                    height={300}
                  />
                </Row>
              </SimpleCard>
            </Col>
          </Row>
        </Col>

        <Row gap={0} className="w-full">
          <Col span={12} md={12} lg={12} sm={12}>
            <SimpleTable
              tableStructure={TxnHistoryStructure}
              title={'Suspicious Txn History'}
            ></SimpleTable>
          </Col>
        </Row>

        <Row gap={0} className="w-full">
          <Col span={12} md={12} lg={12} sm={12}>
            <SimpleTable
              tableStructure={TxnHistoryStructure}
              title={'Rule Audit'}
            ></SimpleTable>
          </Col>
        </Row>

        <Row gap={0} className="w-full">
          <Col span={12} md={12} lg={12} sm={12}>
            <SimpleTable
              tableStructure={TxnHistoryStructure}
              title={'Mandates'}
            ></SimpleTable>
          </Col>
        </Row>

        <Row gap={0} className="w-full">
          <Col span={12} md={12} lg={12} sm={12}>
            <SimpleTable
              tableStructure={TxnHistoryStructure}
              title={'Linked Accounts'}
            ></SimpleTable>
          </Col>
        </Row>
      </Row>
    </TableLayout>
  );
}

export default ViewCustomers;
