import {
  Col,
  IconButton,
  MutedBgLayout,
  NGPBar,
  NGPHeatMap,
  NGPLine,
  NGPMultiBar,
  NGPPieRoundedCorner,
  NGPRadar,
  Row,
  SectionCard,
  SimpleCard
} from '@ais/components';
import CategoryScale from 'CategoryScale';
import Chart from 'Chart';
import Heading from 'Heading';
import WithSession from 'WithSession';
import React from 'react';
import useModalHost from 'useModalHost';

Chart.register(CategoryScale);
function Flow({ appPrimaryColor, appSecondaryColor }) {

  const pieData = [
    { name: 'STR', value: 15000 },
    { name: 'CTR', value: 200 },
    { name: 'CBWT', value: 150 },
    { name: 'NTR', value: 300 },
  ];

  const radarData = [
    { channel: 'UPI', transactions: 120 },
    { channel: 'ATM', transactions: 98 },
    { channel: 'CC', transactions: 86 },
    { channel: 'MB', transactions: 99 },
    { channel: 'IB', transactions: 85 },
  ];

  const barData = [
    { name: 'Customer 1', total: 10 },
    { name: 'Customer 10', total: 50 },
    { name: 'Customer 16', total: 40 },
    { name: 'Customer 26', total: 1 },
  ];

  const repeatedCustomer = [
    { name: 'Customer 15', total: 100 },
    { name: 'Customer 46', total: 160 },
    { name: 'Customer 234', total: 75 },
    { name: 'Customer 26', total: 200 },
    { name: 'Customer 65', total: 75 },
    { name: 'Customer 89', total: 200 },
  ];

  React.useEffect(() => {
    console.log(appPrimaryColor, appSecondaryColor);
  }, [appPrimaryColor, appSecondaryColor]);

  const { showPluginModal } = useModalHost();
  return (
    <MutedBgLayout>
      <Heading
        className={`p-2`}
        title="Dashboard"
        subTitle="Your Day At Glance"
      >
        {/* <div className={`flex-end`}>
        <div>
            <label>
              Filter : <People />
            </label>
            <select aria-label="Default select example">
              <option>Open this select menu</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
        </div>
           */}
      </Heading>

      <Row gap="0" nowrap={false}>
        <Col span="flex" padding={false} className="p-2">
          <SectionCard gap="0" title="STR" subtitle="Suspicious Transaction Report">
            <div className="text-2xl font-bold text-destructive">15,000</div>
          </SectionCard>
        </Col>

        <Col span="flex" padding={false} className="p-2">
          <SectionCard gap="0" title="CTR" subtitle={`Cash Transaction Report`}>
            <div className="text-2xl font-bold text-primary">200</div>
            {/* <p className="text-muted-foreground text-primary text-xs">
              -5% from last month
            </p> */}
          </SectionCard>
        </Col>
        <Col span="flex" padding={false} className="p-2">
          <SectionCard gap="0" title="NTR" subtitle={`Non-profit Org Transaction Report`}>
            <div className="text-2xl font-bold text-warning">300</div>
            {/* <p className="text-muted-foreground text-warning text-xs">
              +10.1% from last month
            </p> */}
          </SectionCard>
        </Col>

        <Col span="flex" padding={false} className="p-2">
          <SectionCard className={`flex-col`} gap="0" title="CBWTR" subtitle={`Cross Border Transaction Report`}>
            <div className="text-2xl font-bold text-info">150</div>
            {/* <p className="text-muted-foreground text-primary text-xs">
              -5% from last month
            </p> */}
          </SectionCard>
        </Col>


      </Row>

      <Row>
        <Col span='12'>
          <SimpleCard align='start' title={`Top 10 Reported Customers`} subtitle={`No:of Customers repeatedly reported in GOVT Channels`} customHeaderComponents={(<>
            <IconButton icon={"Eye"} label={"View"} variant={`secondary`} onClick={() => showPluginModal('v2-customers-recurring-customer-list', { size: 'lg' })} />
          </>)}>
            <NGPMultiBar barData={barData} colorIndex={1} />
          </SimpleCard>
        </Col>
      </Row>

      <Row gap='0'>
        <Col span='6'>
          <SimpleCard align='start' title={`Recurring customer patterns`} subtitle={`No:of Customers who's txn accounted in multiple alert category`} customHeaderComponents={(<>
            <IconButton icon={"Eye"} label={"View"} variant={`secondary`} onClick={() => showPluginModal('v2-customers-recurring-customer-list', { size: 'lg' })} />
          </>)}>
            <NGPBar barData={barData} colorIndex={1} />
          </SimpleCard>
        </Col>

        <Col span='6'>
          <SimpleCard align='start' title={`Repeated customers`} subtitle={`No:of Customers who's txn accounted in multiple days`}
            customHeaderComponents={(<>  <IconButton icon={"Eye"} label={"View"} onClick={() => showPluginModal('v2-customers-repeated-customer-list', { size: 'lg' })} variant={`secondary`} /></>)}
          >
            <NGPBar barData={repeatedCustomer} colorIndex={2} />
          </SimpleCard>
        </Col>
      </Row>

      <Row gap={0}>
        <Col span="4" gap={0}>
          <SimpleCard title="Suspicious Txn Count">
            <NGPRadar radarData={radarData} />
          </SimpleCard>
        </Col>
        <Col span="8" gap={0}>
          <SimpleCard title="Top 10 Suspicious Account Branches">
            <NGPBar />
          </SimpleCard>
        </Col>
      </Row>

      <Row gap={0}>
        <Col span="8" gap={0}>
          <SimpleCard title="Rule vs Transactions">
            <NGPLine />
          </SimpleCard>
        </Col>
        <Col span="4" gap={0}>
          <SimpleCard title="Risk Ratio">
            <NGPPieRoundedCorner pieData={pieData} />
          </SimpleCard>
        </Col>
      </Row>

      <Row gap={0}>
        <Col span="12" gap={0}>
          <SimpleCard title="Suspicious Transaction HeatMap">
            <NGPHeatMap />
          </SimpleCard>
        </Col>
      </Row>
    </MutedBgLayout>
  );
}

export default WithSession(Flow);
