window.env = {
  PLUGIN_URL: 'http://localhost:9000',
  BACKEND_URL: 'http://localhost:8080',
};
