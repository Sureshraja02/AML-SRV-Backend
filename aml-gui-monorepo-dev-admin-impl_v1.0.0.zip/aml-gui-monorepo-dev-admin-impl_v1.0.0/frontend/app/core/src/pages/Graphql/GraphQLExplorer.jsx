import React, { useEffect, useState } from 'react';
// import GraphiQL  to have access to GraphiQL  tools
import { GraphiQL } from 'graphiql';
//Import graphql features that you want to use in your GraphiQL
import { explorerPlugin } from '@graphiql/plugin-explorer';
import 'graphiql/style.css';
import { GRAPHQL_URL } from '../../config';

const GRAPHQL_ENDPOINT = GRAPHQL_URL; // Spring Boot GraphQL path

const GraphQLExplorer = () => {
  const [theme, setTheme] = React.useState('dark');
  const [query, setQuery] = useState('');
  const [tabs, setTabs] = useState([]);
  const [activeTab, setActiveTab] = useState(0);

  // Load history from localStorage
  useEffect(() => {
    const storedTabs = localStorage.getItem('graphql_tabs');
    if (storedTabs) {
      const parsed = JSON.parse(storedTabs);
      setTabs(parsed);
      setQuery(parsed[0] || '');
    } else {
      setTabs(['']);
    }
  }, []);

  // Save history on tab change
  useEffect(() => {
    localStorage.setItem('graphql_tabs', JSON.stringify(tabs));
  }, [tabs]);

  const fetcher = async (graphQLParams) => {
    const response = await fetch(GRAPHQL_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(graphQLParams),
    });
    return response.json();
  };

  const handleQueryChange = (newQuery) => {
    const newTabs = [...tabs];
    newTabs[activeTab] = newQuery;
    setTabs(newTabs);
    setQuery(newQuery);
  };

  const addTab = () => {
    setTabs([...tabs, '']);
    setActiveTab(tabs.length);
  };

  const closeTab = (index) => {
    const newTabs = tabs.filter((_, i) => i !== index);
    setTabs(newTabs);
    setActiveTab(Math.max(0, index - 1));
    setQuery(newTabs[Math.max(0, index - 1)] || '');
  };

  const explorer = explorerPlugin();

  return (
    <>
      <div style={{ height: '100vh' }}>
        {/* <GraphiQL
          fetcher={fetcher}
          initialQuery={query}
          onEditQuery={handleQueryChange}
          editorTheme={theme === 'dark' ? 'dracula' : 'default'}
          defaultEditorToolsVisibility={true}
        /> */}

        <div className="graphiql-container">
          <GraphiQL
            //   ref={(ref) => (this._graphiql = ref)}
            fetcher={fetcher}
            onEditQuery={setQuery}
            query={query}
          ></GraphiQL>
        </div>
      </div>
    </>
  );
};

export default GraphQLExplorer;
