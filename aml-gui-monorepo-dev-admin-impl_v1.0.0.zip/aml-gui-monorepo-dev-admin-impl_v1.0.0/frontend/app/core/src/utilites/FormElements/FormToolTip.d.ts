export default FormToolTip;
declare function FormToolTip({ tooltip, id }: {
    tooltip: any;
    id: any;
}): any;
