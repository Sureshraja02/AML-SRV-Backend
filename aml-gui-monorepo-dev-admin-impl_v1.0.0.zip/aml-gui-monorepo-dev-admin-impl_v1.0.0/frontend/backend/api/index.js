import api, { injectStore } from "./BackendAPI";

export { api, injectStore };

export default api;

