//no slash at the end of the url

export const API_URL = __PLUGIN_URL__;
export const BACKEND_URL = __BACKEND_URL__;
export const CONTEXT_PATH = __CONTEXT_PATH__;
export const ENCRYPT_ON_TRANSIT = false;
export const GRAPHQL_URL = __GRAPHQL_URL__;
export const BACKEND_CALL_TYPE = 'GRAPHQL';

export const HTTP_HEADERS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization',
  Accept: '*/*',
  // add sub-headers in case of any.
};
