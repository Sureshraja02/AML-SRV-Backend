import { startProxyServer } from './proxy';

export default startProxyServer;

