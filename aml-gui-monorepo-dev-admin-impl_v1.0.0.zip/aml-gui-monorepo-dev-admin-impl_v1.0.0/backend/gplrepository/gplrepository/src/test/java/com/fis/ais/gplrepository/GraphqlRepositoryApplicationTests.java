package com.fis.ngp.gplrepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
