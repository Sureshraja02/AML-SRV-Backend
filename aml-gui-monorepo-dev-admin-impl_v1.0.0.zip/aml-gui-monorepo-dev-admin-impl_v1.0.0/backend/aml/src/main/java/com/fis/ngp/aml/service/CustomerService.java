package com.fis.ngp.aml.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.fis.ngp.aml.entity.CustomerEntity;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class CustomerService extends BaseResolver<CustomerEntity, String> {

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return "CUSTOMER";
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ_BY_ID);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return "AML";
	}

}
