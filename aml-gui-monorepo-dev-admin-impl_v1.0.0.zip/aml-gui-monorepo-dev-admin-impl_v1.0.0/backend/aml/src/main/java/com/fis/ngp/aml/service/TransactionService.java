package com.fis.ngp.aml.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.fis.ngp.aml.entity.TransactionEntity;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class TransactionService extends BaseResolver<TransactionEntity, String> {

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return "TRANSACTION";
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ_BY_ID);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return "AML";
	}

}
