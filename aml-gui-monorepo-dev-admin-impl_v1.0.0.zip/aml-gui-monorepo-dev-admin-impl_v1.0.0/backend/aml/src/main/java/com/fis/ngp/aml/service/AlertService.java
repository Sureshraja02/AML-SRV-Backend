package com.fis.ngp.aml.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.ngp.aml.entity.AlertsEntity;
import com.fis.ngp.aml.entity.DTO.AlertsDTO;
import com.fis.ngp.aml.repo.AlertRepo;
import com.fis.ngp.factory.annotations.GraphQLMutation;
import com.fis.ngp.factory.annotations.GraphQLQuery;
import com.fis.ngp.factory.annotations.Required;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.interfaces.EntityInterface;
import com.fis.ngp.factory.interfaces.PrincipalService;
import com.fis.ngp.factory.interfaces.Workflowinterface;
import com.fis.ngp.factory.pojo.BaseEntity;
import com.fis.ngp.factory.pojo.FilterCriteria;
import com.fis.ngp.factory.pojo.PagedResult;
import com.fis.ngp.factory.pojo.SortCriteria;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class AlertService extends BaseResolver<AlertsEntity, String> {

	@Autowired
	AlertRepo alertRepo;

	@Autowired
	Workflowinterface workflowService;

	@Autowired
	PrincipalService prinicipal;

	@Autowired
	EntityInterface entityService;

	@Autowired
	ObjectMapper obj;

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return "ALERTS";
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ, Operations.UPDATE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return "AML";
	}

	@GraphQLQuery
	public List<AlertsEntity> findAlertsByParentId(String parentId) {
		return alertRepo.findByAlertParentId(parentId);
	}

	@GraphQLQuery
	public PagedResult<AlertsEntity> findAlertsByPaging(Integer pageNo, Integer pageSize, SortCriteria sort,
			List<FilterCriteria> filter) {

		// forceId column

		sort.setField("alertId");

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		// MAIN query to return Alert entities
		CriteriaQuery<AlertsEntity> cq = cb.createQuery(AlertsEntity.class);
		Root<AlertsEntity> root = cq.from(AlertsEntity.class);

		// -------------------------
		// SUBQUERY: one alertId per parentAlertId
		// -------------------------
		Subquery<Long> sq = cq.subquery(Long.class);
		Root<AlertsEntity> subRoot = sq.from(AlertsEntity.class);

		// Apply filters inside subquery - REQUIRED!
		List<Predicate> subPredicates = new ArrayList<>();

		for (FilterCriteria fc : filter) {
			if (fc.getValue() == null)
				continue;

			if (fc.getValue() instanceof String) {
				subPredicates.add(cb.like(cb.lower(subRoot.get(fc.getField())),
						"%" + ((String) fc.getValue()).toLowerCase() + "%"));
			} else {
				subPredicates.add(cb.equal(subRoot.get(fc.getField()), fc.getValue()));
			}
		}

		sq.select(cb.max(subRoot.get("alertId"))); // choose representative
		sq.where(subPredicates.toArray(Predicate[]::new));
		sq.groupBy(subRoot.get("alertParentId"));

		// -------------------------
		// MAIN QUERY filters
		// -------------------------
		List<Predicate> predicates = new ArrayList<>();

		for (FilterCriteria fc : filter) {
			if (fc.getValue() == null)
				continue;

			if (fc.getValue() instanceof String) {
				predicates.add(
						cb.like(cb.lower(root.get(fc.getField())), "%" + ((String) fc.getValue()).toLowerCase() + "%"));
			} else {
				predicates.add(cb.equal(root.get(fc.getField()), fc.getValue()));
			}
		}

		// Only select rows whose alertId is in the grouped set
		predicates.add(root.get("alertId").in(sq));

		cq.where(predicates.toArray(Predicate[]::new));

		// -------------------------
		// SORT
		// -------------------------
		if (sort != null && sort.getField() != null) {
			if ("ASC".equalsIgnoreCase(sort.getDirection())) {
				cq.orderBy(cb.asc(root.get(sort.getField())));
			} else {
				cq.orderBy(cb.desc(root.get(sort.getField())));
			}
		}

		TypedQuery<AlertsEntity> query = entityManager.createQuery(cq);

		// paging
		query.setFirstResult((pageNo - 1) * pageSize);
		query.setMaxResults(pageSize);

		List<AlertsEntity> items = query.getResultList();

		// -------------------------
		// COUNT DISTINCT parentAlertId
		// -------------------------
		CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
		Root<AlertsEntity> countRoot = countQuery.from(AlertsEntity.class);

		List<Predicate> countPreds = new ArrayList<>();
		for (FilterCriteria fc : filter) {
			if (fc.getValue() == null)
				continue;

			if (fc.getValue() instanceof String) {
				countPreds.add(cb.like(cb.lower(countRoot.get(fc.getField())),
						"%" + ((String) fc.getValue()).toLowerCase() + "%"));
			} else {
				countPreds.add(cb.equal(countRoot.get(fc.getField()), fc.getValue()));
			}
		}

		countQuery.select(cb.countDistinct(countRoot.get("alertParentId")));
		countQuery.where(countPreds.toArray(Predicate[]::new));

		Long totalElements = entityManager.createQuery(countQuery).getSingleResult();

		int totalPages = (int) Math.ceil((double) totalElements / pageSize);
		boolean isFirst = pageNo == 1;
		boolean isLast = pageNo >= totalPages;

		return new PagedResult<AlertsEntity>(items, totalElements, totalPages, pageNo, isFirst, isLast);

	}

	@GraphQLMutation
	public boolean updateAlertsViaReview(AlertsDTO alert) {
		if (alert.getParentId() != null && alert.getInstanceId() != null) {
			List<Integer> result = workflowService.approveInstance(Long.valueOf(alert.getInstanceId()),
					alert.getComments(), alert.isApproved());

			if (result.size() == 3) {
				int currentlevel = result.get(0);
				int nextlevel = result.get(1);
				int maxLevel = result.get(2);

				String status = "LEVEL " + currentlevel;

				if (!alert.isApproved()) {
					status = "REJECTED";
				} else if (nextlevel > maxLevel) {
					status = "APPROVED";
				}

				alertRepo.updateStatusByParentId(status, alert.getParentId());
			}

			return true;
		}

		return false;
	}

	@GraphQLQuery
	public List<AlertsDTO> findClutchedAlerts() {

		List<Object[]> alertsList = alertRepo
				.findAlertsByStatusNotIn(Arrays.asList("PENDING", "REVIEW", "APPROVED", "REJECTED"));

		List<AlertsDTO> alerts = new ArrayList<AlertsDTO>();

		for (Object[] obj : alertsList) {
			String parentId = (String) obj[0];
			Long alertId = (Long) obj[1];
			String customerId = (String) obj[2];
			String status = (String) obj[3];

			AlertsDTO dto = new AlertsDTO(parentId, customerId, alertId, "-", status);

			alerts.add(dto);

		}

		return alerts;
	}

	@GraphQLQuery
	public List<AlertsDTO> findAlertsByStatus(String status) {

		List<Object[]> alertsList = alertRepo.findAlertsByStatus(status);

		List<AlertsDTO> alerts = new ArrayList<AlertsDTO>();

		for (Object[] obj : alertsList) {
			String parentId = (String) obj[0];
			Long alertId = (Long) obj[1];
			String customerId = (String) obj[2];
			String tstatus = (String) obj[3];

			AlertsDTO dto = new AlertsDTO(parentId, customerId, alertId, "-", tstatus);

			alerts.add(dto);

		}

		return alerts;

	}

	@Scheduled(fixedDelay = 60000) // 1 min wait for the previous thread and starts at next minute
	public void ParseAlerts() throws JsonProcessingException {
		String status = "PENDING";

		String entityAction = "UPDATE";

		String entityModule = getEntityID();

		if (entityService.isEntityexists(entityModule, entityAction)) {
			String entityId = Long.toString(entityService.getEntityById(entityModule, entityAction));

			// isworlflow present ?
			if (workflowService.isWorkflowPresent(entityId)) {
				Long workflowId = workflowService.getWorkflowId(entityId);
				List<Object[]> alertsList = alertRepo.findAlertsByStatus(status);

				System.out.println("entities marked  for workflow : " + alertsList.size());

				for (Object[] object : alertsList) {
					String parentId = (String) object[0];
					Long alertId = (Long) object[1];
					String customerId = (String) object[2];
					String rstatus = (String) object[3];

					AlertsDTO dto = new AlertsDTO(parentId, customerId, alertId, "-", rstatus);

					String payload = obj.writeValueAsString(dto);

					System.out.println(payload);

					if (!workflowService.isEntityPresentinData(parentId, entityId)) {

						workflowService.SubmitDataToWorkflow(workflowId, payload, "system", parentId, entityId);

					}
					alertRepo.updateStatusByParentId("REVIEW", parentId);
				}
			}
		}
	}

}
