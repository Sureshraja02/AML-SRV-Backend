package com.fis.ngp.aml.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

@Entity
@Immutable
@Subselect("SELECT * FROM fs_trn")
public class TransactionEntity {

	@Id
	private String transactionid;

	private String transactionbatchid;

	private Long customerid;

	private Long accountno;

	private String branchcode;

	private String transactiontype;

	private String channeltype;

	private String channelid;

	private String transactiondate;

	private String transactiontime;

	private Double amount;

	private String depositorwithdrawal;

	private String flowcode;

	private String instrumentcode;

	private String instrumentno;

	private String instrumentdate;

	private String micrcode;

	private String acctcurrencycode;

	private String currencycode;

	private String originalcurrencytrnamt;

	private String ratecode;

	private String conversionrate;

	private String narration;

	private String remarks;

	private Long refno;

	private String creationuserid;

	private Long posteduserid;

	private String forexremittance;

	private String counterpartyid;

	private String counterpartyname;

	private Long counterpartyaccountno;

	private String counterpartytype;

	private String counterbankcode;

	private String counterbranchcode;

	private String counterpartyaddress;

	private String countercountrycode;

	private Long accountcurrencytrnamt;

	private Long balanceamount;

	private String postingdate;

	private String merchantcategorycode;

	public String getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}

	public String getTransactionbatchid() {
		return transactionbatchid;
	}

	public void setTransactionbatchid(String transactionbatchid) {
		this.transactionbatchid = transactionbatchid;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public String getChanneltype() {
		return channeltype;
	}

	public void setChanneltype(String channeltype) {
		this.channeltype = channeltype;
	}

	public String getChannelid() {
		return channelid;
	}

	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}

	public String getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}

	public String getTransactiontime() {
		return transactiontime;
	}

	public void setTransactiontime(String transactiontime) {
		this.transactiontime = transactiontime;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getDepositorwithdrawal() {
		return depositorwithdrawal;
	}

	public void setDepositorwithdrawal(String depositorwithdrawal) {
		this.depositorwithdrawal = depositorwithdrawal;
	}

	public String getFlowcode() {
		return flowcode;
	}

	public void setFlowcode(String flowcode) {
		this.flowcode = flowcode;
	}

	public String getInstrumentcode() {
		return instrumentcode;
	}

	public void setInstrumentcode(String instrumentcode) {
		this.instrumentcode = instrumentcode;
	}

	public String getInstrumentno() {
		return instrumentno;
	}

	public void setInstrumentno(String instrumentno) {
		this.instrumentno = instrumentno;
	}

	public String getInstrumentdate() {
		return instrumentdate;
	}

	public void setInstrumentdate(String instrumentdate) {
		this.instrumentdate = instrumentdate;
	}

	public String getMicrcode() {
		return micrcode;
	}

	public void setMicrcode(String micrcode) {
		this.micrcode = micrcode;
	}

	public String getAcctcurrencycode() {
		return acctcurrencycode;
	}

	public void setAcctcurrencycode(String acctcurrencycode) {
		this.acctcurrencycode = acctcurrencycode;
	}

	public String getCurrencycode() {
		return currencycode;
	}

	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}

	public String getOriginalcurrencytrnamt() {
		return originalcurrencytrnamt;
	}

	public void setOriginalcurrencytrnamt(String originalcurrencytrnamt) {
		this.originalcurrencytrnamt = originalcurrencytrnamt;
	}

	public String getRatecode() {
		return ratecode;
	}

	public void setRatecode(String ratecode) {
		this.ratecode = ratecode;
	}

	public String getConversionrate() {
		return conversionrate;
	}

	public void setConversionrate(String conversionrate) {
		this.conversionrate = conversionrate;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreationuserid() {
		return creationuserid;
	}

	public void setCreationuserid(String creationuserid) {
		this.creationuserid = creationuserid;
	}

	public String getForexremittance() {
		return forexremittance;
	}

	public void setForexremittance(String forexremittance) {
		this.forexremittance = forexremittance;
	}

	public String getCounterpartyid() {
		return counterpartyid;
	}

	public void setCounterpartyid(String counterpartyid) {
		this.counterpartyid = counterpartyid;
	}

	public String getCounterpartyname() {
		return counterpartyname;
	}

	public void setCounterpartyname(String counterpartyname) {
		this.counterpartyname = counterpartyname;
	}

	public String getCounterpartytype() {
		return counterpartytype;
	}

	public void setCounterpartytype(String counterpartytype) {
		this.counterpartytype = counterpartytype;
	}

	public String getCounterbankcode() {
		return counterbankcode;
	}

	public void setCounterbankcode(String counterbankcode) {
		this.counterbankcode = counterbankcode;
	}

	public String getCounterbranchcode() {
		return counterbranchcode;
	}

	public void setCounterbranchcode(String counterbranchcode) {
		this.counterbranchcode = counterbranchcode;
	}

	public String getCounterpartyaddress() {
		return counterpartyaddress;
	}

	public void setCounterpartyaddress(String counterpartyaddress) {
		this.counterpartyaddress = counterpartyaddress;
	}

	public String getCountercountrycode() {
		return countercountrycode;
	}

	public void setCountercountrycode(String countercountrycode) {
		this.countercountrycode = countercountrycode;
	}

	public String getPostingdate() {
		return postingdate;
	}

	public void setPostingdate(String postingdate) {
		this.postingdate = postingdate;
	}

	public String getMerchantcategorycode() {
		return merchantcategorycode;
	}

	public void setMerchantcategorycode(String merchantcategorycode) {
		this.merchantcategorycode = merchantcategorycode;
	}

	public Long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Long customerid) {
		this.customerid = customerid;
	}

	public Long getAccountno() {
		return accountno;
	}

	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}

	public Long getRefno() {
		return refno;
	}

	public void setRefno(Long refno) {
		this.refno = refno;
	}

	public Long getPosteduserid() {
		return posteduserid;
	}

	public void setPosteduserid(Long posteduserid) {
		this.posteduserid = posteduserid;
	}

	public Long getCounterpartyaccountno() {
		return counterpartyaccountno;
	}

	public void setCounterpartyaccountno(Long counterpartyaccountno) {
		this.counterpartyaccountno = counterpartyaccountno;
	}

	public Long getAccountcurrencytrnamt() {
		return accountcurrencytrnamt;
	}

	public void setAccountcurrencytrnamt(Long accountcurrencytrnamt) {
		this.accountcurrencytrnamt = accountcurrencytrnamt;
	}

	public Long getBalanceamount() {
		return balanceamount;
	}

	public void setBalanceamount(Long balanceamount) {
		this.balanceamount = balanceamount;
	}

}
