package com.fis.ngp.aml.entity.DTO;

public class AlertsDTO {

	private String parentId;

	private String customerId;

	private Long alertId;

	private String customerAccountType;

	private String instanceId;

	private String comments;

	private boolean isApproved;
	
	private String status;
	
	
	public AlertsDTO() {
	}

	public AlertsDTO(String parentId, String customerId, Long alertId, String customerAccountType,String status) {
		this.parentId = parentId;
		this.customerId = customerId;
		this.alertId = alertId;
		this.customerAccountType = customerAccountType;
		this.status = status;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerAccountType() {
		return customerAccountType;
	}

	public void setCustomerAccountType(String customerAccountType) {
		this.customerAccountType = customerAccountType;
	}

	public Long getAlertId() {
		return alertId;
	}

	public void setAlertId(Long alertId) {
		this.alertId = alertId;
	}

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public boolean isApproved() {
		return isApproved;
	}

	public void setApproved(boolean isApproved) {
		this.isApproved = isApproved;
	}

}
