package com.fis.ngp.aml.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.aml.entity.TransactionEntity;

public interface TransactionRepo extends JpaRepository<TransactionEntity, String> {

}
