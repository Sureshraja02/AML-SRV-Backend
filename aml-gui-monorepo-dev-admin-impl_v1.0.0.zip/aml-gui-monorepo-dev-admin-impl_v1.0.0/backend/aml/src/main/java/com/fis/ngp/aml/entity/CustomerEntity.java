package com.fis.ngp.aml.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

@Entity
@Immutable
@Subselect("SELECT * FROM fs_cust")
public class CustomerEntity {

	@Id
	private String customerid;

	private String customername;

	private String customertype;

	private String customercategory;

	private String minor;

	private String wblist;

	private String bankcode;

	private String branchcode;

	private String natureofbusiness;

	private String creditrating;

	private String createddatetime;

	private String introducercustomerid;
	private String introducername;
	private String introducercategory;

	private String customerempcode;

	private Integer estimatedincomefrombusiness;

	private Integer otherincome;

	private Integer annualincome;

	private Integer net_worth;

	private String checked;

	private String intercountry;

	private String fatfncct;

	private String drugtrafficking;

	public String getCustomerid() {
		return customerid;
	}

	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCustomertype() {
		return customertype;
	}

	public void setCustomertype(String customertype) {
		this.customertype = customertype;
	}

	public String getCustomercategory() {
		return customercategory;
	}

	public void setCustomercategory(String customercategory) {
		this.customercategory = customercategory;
	}

	public String getMinor() {
		return minor;
	}

	public void setMinor(String minor) {
		this.minor = minor;
	}

	public String getWblist() {
		return wblist;
	}

	public void setWblist(String wblist) {
		this.wblist = wblist;
	}

	public String getBankcode() {
		return bankcode;
	}

	public void setBankcode(String bankcode) {
		this.bankcode = bankcode;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getNatureofbusiness() {
		return natureofbusiness;
	}

	public void setNatureofbusiness(String natureofbusiness) {
		this.natureofbusiness = natureofbusiness;
	}

	public String getCreditrating() {
		return creditrating;
	}

	public void setCreditrating(String creditrating) {
		this.creditrating = creditrating;
	}

	public String getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(String createddatetime) {
		this.createddatetime = createddatetime;
	}

	public String getIntroducercustomerid() {
		return introducercustomerid;
	}

	public void setIntroducercustomerid(String introducercustomerid) {
		this.introducercustomerid = introducercustomerid;
	}

	public String getIntroducername() {
		return introducername;
	}

	public void setIntroducername(String introducername) {
		this.introducername = introducername;
	}

	public String getIntroducercategory() {
		return introducercategory;
	}

	public void setIntroducercategory(String introducercategory) {
		this.introducercategory = introducercategory;
	}

	public String getCustomerempcode() {
		return customerempcode;
	}

	public void setCustomerempcode(String customerempcode) {
		this.customerempcode = customerempcode;
	}

	public Integer getEstimatedincomefrombusiness() {
		return estimatedincomefrombusiness;
	}

	public void setEstimatedincomefrombusiness(Integer estimatedincomefrombusiness) {
		this.estimatedincomefrombusiness = estimatedincomefrombusiness;
	}

	public Integer getOtherincome() {
		return otherincome;
	}

	public void setOtherincome(Integer otherincome) {
		this.otherincome = otherincome;
	}

	public Integer getAnnualincome() {
		return annualincome;
	}

	public void setAnnualincome(Integer annualincome) {
		this.annualincome = annualincome;
	}

	public Integer getNet_worth() {
		return net_worth;
	}

	public void setNet_worth(Integer net_worth) {
		this.net_worth = net_worth;
	}

	public String getChecked() {
		return checked;
	}

	public void setChecked(String checked) {
		this.checked = checked;
	}

	public String getIntercountry() {
		return intercountry;
	}

	public void setIntercountry(String intercountry) {
		this.intercountry = intercountry;
	}

	public String getFatfncct() {
		return fatfncct;
	}

	public void setFatfncct(String fatfncct) {
		this.fatfncct = fatfncct;
	}

	public String getDrugtrafficking() {
		return drugtrafficking;
	}

	public void setDrugtrafficking(String drugtrafficking) {
		this.drugtrafficking = drugtrafficking;
	}

}
