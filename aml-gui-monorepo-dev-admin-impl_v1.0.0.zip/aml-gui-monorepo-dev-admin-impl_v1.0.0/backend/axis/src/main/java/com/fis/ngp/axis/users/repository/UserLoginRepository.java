package com.fis.ngp.axis.users.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fis.ngp.axis.users.entity.UserLogin;

@Repository
public interface UserLoginRepository extends JpaRepository<UserLogin, Long> {

	Optional<UserLogin> findByUsername(String username);

	Optional<UserLogin> findByUsernameAndUserStatus(String username, Boolean status);

}
