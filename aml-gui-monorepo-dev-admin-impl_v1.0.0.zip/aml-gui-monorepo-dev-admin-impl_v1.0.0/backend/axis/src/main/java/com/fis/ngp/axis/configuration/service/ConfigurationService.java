package com.fis.ngp.axis.configuration.service;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.fis.ngp.axis.configuration.modal.Configuration;
import com.fis.ngp.factory.annotations.GraphQLMutation;
import com.fis.ngp.factory.enums.Commons;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.interfaces.AppConfigurations;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class ConfigurationService extends BaseResolver<Configuration, UUID> implements AppConfigurations {

	private static final String entityID = "CONFIG";

	@GraphQLMutation(name = "saveOrUpdateConfig")
	public List<Configuration> addOrUpdateConfigurations(List<Configuration> configs) {
		System.out.println("Config List : " + configs.size());
		return configs;
	}

	@Override
	public Object getConfigByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return entityID;
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ, Operations.READ_BY_ID, Operations.SAVE, Operations.DISABLE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return Commons.CORE.toString();
	}

}
