package com.fis.ngp.axis.users.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.ngp.axis.users.entity.GroupEntity;
import com.fis.ngp.axis.users.repository.GroupRepository;
import com.fis.ngp.entityHub.entity.EntityMaster;
import com.fis.ngp.factory.enums.Commons;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class GroupService extends BaseResolver<GroupEntity, Long> {

	@Autowired
	GroupRepository grpRepo;

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return "GRP";
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ, Operations.READ_BY_ID, Operations.READ_BY_PAGING, Operations.DISABLE,
				Operations.UPDATE, Operations.SAVE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return Commons.CORE.name();
	}

	public List<EntityMaster> findByGroupId(Long grpId) {
		return grpRepo.findAllByGroupId(grpId);
	}

}
