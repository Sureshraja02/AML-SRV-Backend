package com.fis.ngp.axis.Institutions.service;

import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.fis.ngp.factory.enums.Commons;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.template.BaseResolver;
import com.fis.ngp.axis.Institutions.entity.EventsEntity;

@Service
public class EventsService extends BaseResolver<EventsEntity, UUID> {
	private static final String entityID = "EVENT";

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ, Operations.SAVE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return Commons.CORE.toString();
	}

}
