package com.fis.ngp.axis.users.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.ngp.factory.annotations.GraphQLMutation;
import com.fis.ngp.factory.annotations.GraphQLQuery;
import com.fis.ngp.factory.annotations.Required;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.errors.GenericErrorException;
import com.fis.ngp.factory.interfaces.PrincipalService;
import com.fis.ngp.factory.pojo.LoginResponseEntity;
import com.fis.ngp.factory.template.BaseResolver;
import com.fis.ngp.axis.users.entity.GroupEntity;
import com.fis.ngp.axis.users.entity.UserLogin;
import com.fis.ngp.axis.users.entity.UserProfile;
import com.fis.ngp.axis.users.repository.UserLoginRepository;
import com.fis.ngp.axis.users.repository.UserProfileRepository;
import com.fis.ngp.entityHub.entity.EntityMaster;

@Service
public class UserProfileService extends BaseResolver<UserProfile, UUID> implements PrincipalService {

	@Autowired
	UserProfileRepository repo;

	@Autowired
	UserLoginRepository loginRepository;

	@Autowired
	ObjectMapper obj;

	@Transactional
	@GraphQLMutation
	public UserProfile saveUserProfileWithLogin(UserProfile userProfile, String password) {
		try {
			System.out.println(obj.writeValueAsString(userProfile));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.save(userProfile);
	}

	public List<UserProfile> findByGroupByUserID(UUID profileId) {
		return repo.findGroupsById(profileId);
	}

	@GraphQLQuery
	public String hello(Integer v1, String v2, Long v3, Boolean v4, List<String> lt, UserLogin us) {

		System.out.println(v1 + v2 + v3 + v4);

		for (String string : lt) {
			System.out.println(string);
		}

		try {
			System.out.println(obj.writeValueAsString(us));
			us.getUserProfile().getGroups().forEach(e -> {
				System.out.println("into groups : " + e.getGroupName());
			});
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		throw new GenericErrorException("1001", "Failed to process contact administrator");
//		System.out.println(principalService.getLoginUser());
//		return "success";
	}

	@GraphQLQuery
	public Optional<UserProfile> findByUserName(@Required String username) {

		return repo.findByUsernameAndActive(username, true);

	}

	@Override
	public String getEntityID() {
		return "USER";
	}

	@Override
	public Set<Operations> getSupportedOperations() {
		return Set.of(Operations.READ, Operations.READ_BY_PAGING, Operations.UPDATE, Operations.DISABLE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return "CORE";
	}

	@Override
	public String getLoginUser() {

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			UserDetails userDetails = (UserDetails) principal;
			return userDetails.getUsername();
		}

		return null;
	}

	@Override
	public List<GroupEntity> getGroups() {
		if (getLoginUser() != null) {
			Optional<UserProfile> optionalUserProfile = repo.findByUsernameAndActive(getLoginUser(), true);

			if (optionalUserProfile.isPresent()) {
				UserProfile up = optionalUserProfile.get();
				return new ArrayList<GroupEntity>(up.getGroups());
			}
		}
		return null;
	}

	@Override
	public List<Long> getGroupsIds() {
		List<Long> ids = new ArrayList<Long>();
		if (getLoginUser() != null) {
			Optional<UserProfile> optionalUserProfile = repo.findByUsernameAndActive(getLoginUser(), true);

			if (optionalUserProfile.isPresent()) {
				UserProfile up = optionalUserProfile.get();

				for (GroupEntity grp : up.getGroups()) {
					ids.add(grp.getId());
				}
			}
		}
		return ids;
	}

	@Override
	public UserProfile getUserProfile() {
		if (getLoginUser() != null) {
			Optional<UserProfile> optionalUserProfile = repo.findByUsernameAndActive(getLoginUser(), true);

			if (optionalUserProfile.isPresent()) {
				UserProfile up = optionalUserProfile.get();
				return up;
			}
		}
		return new UserProfile();
	}
	
	
	@Override
	public Long getuserId() {
		return this.getUserProfile().getId();
	}

	@Override
	public boolean checkEntityisPresent(Long entityId) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			UserDetails userDetails = (UserDetails) principal;

			Optional<UserProfile> optionalUserProfile = repo.findByUsernameAndActive(userDetails.getUsername(), true);

			if (optionalUserProfile.isPresent()) {
				UserProfile up = optionalUserProfile.get();
				Set<GroupEntity> groupList = up.getGroups();

				for (GroupEntity groupEntity : groupList) {
					Set<EntityMaster> entities = groupEntity.getEntities();
					for (EntityMaster ent : entities) {

						if (ent.getId().equals(entityId))
							return true;
					}
				}
			}

		}

		return false;
	}

	@Override
	public LoginResponseEntity getSessionData() {
		LoginResponseEntity requestentity = new LoginResponseEntity();
		String username = this.getLoginUser();

		if (username == null)
			return requestentity;

		Optional<UserLogin> OptUserLogin = loginRepository.findByUsername(username);

		if (OptUserLogin.isPresent()) {
			UserLogin userlogin = OptUserLogin.get();

			requestentity.setUserName(username);
			requestentity.setStatus(userlogin.getPwdStatus());
			requestentity.setInsId(userlogin.getUserProfile().getInsId());
			return requestentity;
		}

		return requestentity;
	}

}
