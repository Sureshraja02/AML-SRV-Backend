package com.fis.ngp.axis.configuration.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fis.ngp.axis.configuration.modal.Configuration;
import com.fis.ngp.axis.configuration.modal.ConfigurationValue;

@Repository
public interface ConfigurationValueRepository extends JpaRepository<ConfigurationValue, UUID> {

	 Optional<ConfigurationValue> findByConfigKey(String key);

}
