package com.fis.ngp.axis.Institutions.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.fis.ngp.factory.pojo.UUIDBaseEntity;

@Entity
@Table(name = "AIS_INS_TB")
public class InstitutionEntity extends UUIDBaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String institutionId;

	private String institutionName;

	private Boolean active;

	public String getInstitutionId() {
		return institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

}
