package com.fis.ngp.rulemanager.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fis.ngp.rulemanager.entity.CatalogExpressionsEntity;

@Repository
public interface RuleCatalogExpressionRepo extends JpaRepository<CatalogExpressionsEntity, Long> {

}
