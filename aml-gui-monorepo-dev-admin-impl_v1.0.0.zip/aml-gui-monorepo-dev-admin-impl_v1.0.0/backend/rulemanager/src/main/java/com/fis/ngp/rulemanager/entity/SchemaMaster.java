package com.fis.ngp.rulemanager.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.fis.ngp.factory.pojo.LongBaseEntity;

@Entity
@Table(name="NGP_SCHEMA_MASTER")
public class SchemaMaster extends LongBaseEntity {

	
	private String schemaName;
	
	private String schemaType = "SCHEMA";

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getSchemaType() {
		return schemaType;
	}

	public void setSchemaType(String schemaType) {
		this.schemaType = schemaType;
	}
	
	
	
	
}
