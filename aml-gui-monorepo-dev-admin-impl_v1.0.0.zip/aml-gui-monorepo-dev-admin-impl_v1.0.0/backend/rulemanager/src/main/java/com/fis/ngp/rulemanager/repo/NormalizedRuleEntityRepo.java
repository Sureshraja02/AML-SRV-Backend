package com.fis.ngp.rulemanager.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.NormalizedRuleEntity;

public interface NormalizedRuleEntityRepo extends JpaRepository<NormalizedRuleEntity, Long> {
	
	Optional<NormalizedRuleEntity> findByRuleName(String ruleName);

}
