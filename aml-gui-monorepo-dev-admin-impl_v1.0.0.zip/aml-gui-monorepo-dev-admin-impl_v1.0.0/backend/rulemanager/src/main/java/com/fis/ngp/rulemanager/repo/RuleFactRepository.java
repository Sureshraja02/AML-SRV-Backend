package com.fis.ngp.rulemanager.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.FactsEntity;

public interface RuleFactRepository extends JpaRepository<FactsEntity, String> {

}
