package com.fis.ngp.rulemanager.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.CatalogTypeEntity;

public interface RuleCatalogTypesRespository extends JpaRepository<CatalogTypeEntity, Long> {

	Optional<CatalogTypeEntity> findByName(String name);

}
