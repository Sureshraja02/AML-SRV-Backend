package com.fis.ngp.rulemanager.repo;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.RuleConditionsEntity;

public interface RuleConditionRepository extends JpaRepository<RuleConditionsEntity, UUID> {

}
