package com.fis.ngp.rulemanager.repo;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.RuleGroupsEntity;

public interface RuleGroupRepository extends JpaRepository<RuleGroupsEntity, UUID> {

}
