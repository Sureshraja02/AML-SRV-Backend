package com.fis.ngp.rulemanager.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.rulemanager.entity.CatalogEntity;

public interface RuleCatalogEntityRepository extends JpaRepository<CatalogEntity, Long> {

//	Optional<CatalogEntity> findByNameAndSchemaName(String name, String schemaName);

	List<CatalogEntity> findBySchema_Id(Long schemaId);

}
