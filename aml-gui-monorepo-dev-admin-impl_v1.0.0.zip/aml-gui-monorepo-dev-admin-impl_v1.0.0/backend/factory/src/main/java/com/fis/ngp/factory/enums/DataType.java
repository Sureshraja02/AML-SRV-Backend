package com.fis.ngp.factory.enums;

public enum DataType {
	STRING, NUMBER, BOOLEAN, DATE, EXPRESSION
}
