package com.fis.ngp.factory.interfaces;

import java.util.List;
import java.util.Map;

import com.fis.ngp.factory.enums.ReportType;
import com.fis.ngp.factory.pojo.ReportField;

public interface ReportPlugin {

	String getPluginId();

	String getPluginName();

	List<ReportField> getReportFields(); // Define ReportFields

	byte[] generateReport(Map<String, Object> fieldValues);

	ReportType getReportType();

}
