package com.fis.ngp.factory.pojo;

public class LoginRequestEntity {

	private String username;
	private String keyword;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	

}
