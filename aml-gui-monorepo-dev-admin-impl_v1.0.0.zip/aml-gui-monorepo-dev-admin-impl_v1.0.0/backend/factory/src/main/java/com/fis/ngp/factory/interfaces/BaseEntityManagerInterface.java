package com.fis.ngp.factory.interfaces;

import java.util.Set;

import com.fis.ngp.factory.enums.Operations;

public interface BaseEntityManagerInterface {

	String getEntityID();

	Set<Operations> getSupportedOperations();

	String getAppID();

}
