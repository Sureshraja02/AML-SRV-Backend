package com.fis.ngp.factory.enums;

public enum LogicalOperator {
    AND,
    OR
}
