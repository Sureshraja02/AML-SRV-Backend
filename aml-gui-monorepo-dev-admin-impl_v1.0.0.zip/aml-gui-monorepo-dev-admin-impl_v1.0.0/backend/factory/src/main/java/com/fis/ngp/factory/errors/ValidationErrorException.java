package com.fis.ngp.factory.errors;

public class ValidationErrorException extends RuntimeException {

	public ValidationErrorException(String message) {
		super(message);
	}

}
