package com.fis.ngp.factory.interfaces;

public interface AppConfigurations {
	
 Object	getConfigByName(String name);

}
