package com.fis.ngp.factory.enums;

public enum Commons {

	CORE, RULE_ENGINE, REPORTS

}
