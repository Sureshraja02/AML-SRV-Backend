package com.fis.ngp.factory.enums;

public enum Operations {

	READ,
	READ_BY_ID,
	SAVE,
	READ_BY_PAGING,
	UPDATE,
	DELETE,
	DISABLE,
	
}
