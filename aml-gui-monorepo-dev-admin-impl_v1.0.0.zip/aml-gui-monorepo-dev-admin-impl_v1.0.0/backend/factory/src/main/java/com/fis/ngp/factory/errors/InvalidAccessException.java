package com.fis.ngp.factory.errors;

public class InvalidAccessException extends RuntimeException {


	public InvalidAccessException(String message) {
		super(message);
	}
}
