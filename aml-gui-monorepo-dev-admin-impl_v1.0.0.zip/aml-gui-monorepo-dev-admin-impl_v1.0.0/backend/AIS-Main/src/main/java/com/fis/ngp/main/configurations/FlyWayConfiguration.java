package com.fis.ngp.main.configurations;

import org.flywaydb.core.Flyway;
import org.springframework.context.annotation.Bean;

public class FlyWayConfiguration {

}
