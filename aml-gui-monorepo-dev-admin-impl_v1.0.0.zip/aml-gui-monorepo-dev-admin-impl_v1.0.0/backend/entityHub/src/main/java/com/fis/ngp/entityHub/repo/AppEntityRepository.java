package com.fis.ngp.entityHub.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fis.ngp.entityHub.entity.AppEntity;
import com.fis.ngp.entityHub.entity.EntityMaster;

@Repository
public interface AppEntityRepository extends JpaRepository<AppEntity, Long> {
	
	AppEntity findByAppId(String appId);
	
	List<AppEntity> findByActive(boolean active);

	List<AppEntity> findByActiveTrue();

}
