package com.fis.ngp.entityHub.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.entityHub.entity.workflow.WorkflowStagingEntity;

public interface WorkflowDataRepo extends JpaRepository<WorkflowStagingEntity, Long> {

	Optional<WorkflowStagingEntity> findByEntityIdAndEntityType(String entityId, String entityType);

}
