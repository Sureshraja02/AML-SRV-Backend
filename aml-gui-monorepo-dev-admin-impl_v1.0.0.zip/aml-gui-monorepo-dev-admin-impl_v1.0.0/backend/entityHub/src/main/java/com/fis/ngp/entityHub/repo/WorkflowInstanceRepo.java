package com.fis.ngp.entityHub.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.entityHub.entity.workflow.WorkflowInstanceEntity;

public interface WorkflowInstanceRepo extends JpaRepository<WorkflowInstanceEntity, Long> {

	List<WorkflowInstanceEntity> findByWorkflowIdInAndStatus(List<Long> workflowIds, String string);

}
