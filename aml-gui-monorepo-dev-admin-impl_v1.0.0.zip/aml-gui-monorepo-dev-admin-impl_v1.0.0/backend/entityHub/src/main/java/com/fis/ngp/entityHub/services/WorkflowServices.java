package com.fis.ngp.entityHub.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.management.RuntimeErrorException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fis.ngp.entityHub.EntityBuilder;
import com.fis.ngp.entityHub.entity.workflow.WorkflowApproverEntity;
import com.fis.ngp.entityHub.entity.workflow.WorkflowEntity;
import com.fis.ngp.entityHub.entity.workflow.WorkflowInstanceEntity;
import com.fis.ngp.entityHub.entity.workflow.WorkflowInstanceHistoryEntity;
import com.fis.ngp.entityHub.entity.workflow.WorkflowStagingEntity;
import com.fis.ngp.entityHub.repo.WorkflowApproversRepo;
import com.fis.ngp.entityHub.repo.WorkflowDataRepo;
import com.fis.ngp.entityHub.repo.WorkflowInstanceHistory;
import com.fis.ngp.entityHub.repo.WorkflowInstanceRepo;
import com.fis.ngp.entityHub.repo.WorkflowRepo;
import com.fis.ngp.factory.annotations.GraphQLMutation;
import com.fis.ngp.factory.annotations.GraphQLQuery;
import com.fis.ngp.factory.enums.Operations;
import com.fis.ngp.factory.interfaces.PrincipalService;
import com.fis.ngp.factory.interfaces.Workflowinterface;
import com.fis.ngp.factory.template.BaseResolver;

@Service
public class WorkflowServices extends BaseResolver<WorkflowEntity, Long> implements Workflowinterface {

	private final EntityBuilder entityBuilder;

	@Autowired
	WorkflowInstanceRepo workflowInstanceRepo;

	@Autowired
	WorkflowInstanceHistory workflowInstanceHistoryRepo;

	@Autowired
	WorkflowRepo workflowRepo;

	@Autowired
	WorkflowDataRepo workflowDataRepo;

	@Autowired
	PrincipalService principal;

	@Autowired
	WorkflowApproversRepo workflowApproverRepo;

	WorkflowServices(EntityBuilder entityBuilder) {
		this.entityBuilder = entityBuilder;
	}

	@Override
	public String getEntityID() {
		// TODO Auto-generated method stub
		return "WORKFLOW";
	}

	@Override
	@Transactional
	public WorkflowEntity save(WorkflowEntity entity) {
		System.out.println("into reference");
		List<WorkflowApproverEntity> existing = entity.getApprovers();
		List<WorkflowApproverEntity> adding = new ArrayList<>();
		for (WorkflowApproverEntity workflowApproverEntity : existing) {

			workflowApproverEntity.setWorkflow(entity);
			adding.add(workflowApproverEntity);
		}
		return super.save(entity);

	}

	@Override
	public Set<Operations> getSupportedOperations() {
		// TODO Auto-generated method stub
		return Set.of(Operations.READ_BY_PAGING, Operations.READ_BY_ID, Operations.SAVE, Operations.UPDATE);
	}

	@Override
	public String getAppID() {
		// TODO Auto-generated method stub
		return "CORE";
	}

	@Override
	public Boolean isWorkflowPresent(String entityType) {

		Optional<WorkflowEntity> optionalWorkflowEntity = workflowRepo.findByEntityType(entityType);

		if (optionalWorkflowEntity.isPresent())
			return true;

		return false;
	}

	@Override
	public Long getWorkflowId(String entityType) {

		WorkflowEntity optionalWorkflowEntity = workflowRepo.findByEntityType(entityType)
				.orElseThrow(() -> new RuntimeException("Workflow not found"));

		return optionalWorkflowEntity.getId();

	}

	@Override
	public Boolean isEntityPresentinData(String entityId, String entityType) {
		Optional<WorkflowStagingEntity> optionalWorklowData = workflowDataRepo.findByEntityIdAndEntityType(entityId,
				entityType);

		if (optionalWorklowData.isPresent()) {
			return true;
		}

		return false;
	}

	@Override
	public void SubmitDataToWorkflow(Long workflowId, String payload, String createdBy, String entityId,
			String entityType) {
		String status = "PENDING";
		Integer currentLevel = 1;

		WorkflowStagingEntity pendingData = new WorkflowStagingEntity();

		pendingData.setPayload(payload);
		pendingData.setEntityId(entityId);
		pendingData.setEntityType(entityType);
		pendingData.setCreatedBy(createdBy);
		pendingData.setStatus(status);

		pendingData = workflowDataRepo.save(pendingData);

		WorkflowInstanceEntity instance = new WorkflowInstanceEntity();

		// get workflow
		WorkflowEntity workflow = workflowRepo.findById(workflowId)
				.orElseThrow(() -> new RuntimeException("Workflow does not exists"));

		instance.setWorkflow(workflow);
		instance.setPendingData(pendingData);
		instance.setEntityId(entityId);
		instance.setEntityType(entityType);
		instance.setCurrentLevel(currentLevel);
		instance.setStatus(status);

		workflowInstanceRepo.save(instance);

	}

	@GraphQLQuery
	public List<WorkflowInstanceHistoryEntity> getWorflowHistoryByParentId(String id) {
		return workflowInstanceHistoryRepo.findByWorkflowInstanceEntityId(id);
	}


	@GraphQLQuery
	public List<WorkflowInstanceEntity> findEntitiesPendingForApproval() {

		Long userId = principal.getuserId();
		List<Long> groups = principal.getGroupsIds();

		List<Long> workflowIds = workflowApproverRepo.findWorkflowEntityIdsForUser(userId, groups);

		if (workflowIds.isEmpty())
			return List.of();

		// 3. fetch workflow instances in PENDING status
		List<WorkflowInstanceEntity> pendingInstances = workflowInstanceRepo.findByWorkflowIdInAndStatus(workflowIds,
				"PENDING");

		// 4. retain only instances where user is approver for CURRENT level
		List<WorkflowInstanceEntity> pendingItesm = pendingInstances.stream().filter(inst -> {

			boolean allowed = isUserAllowedForLevel(userId, inst.getWorkflow().getId(), inst.getCurrentLevel());
//			System.out.println("Filter check for " + inst.getEntityId() + " = " + allowed);
			return allowed;
		}).collect(Collectors.toList());

		return pendingItesm;
	}

	private boolean isUserAllowedForLevel(Long userId, Long workflowEntityId, int level) {

		List<Long> groups = principal.getGroupsIds();
		List<WorkflowApproverEntity> approvers = workflowApproverRepo.findByworkflowIdAndLevelNumber(workflowEntityId,
				level);
		return approvers.stream().anyMatch(a -> (a.getApproverType().equals("USER") && a.getApproverId().equals(userId))
				|| (a.getApproverType().equals("GROUP") && groups.contains(a.getApproverId())));
	}

	@Override
	@GraphQLMutation
	public List<Integer> approveInstance(Long workflowInstanceId, String comments, boolean isApproved) {

		WorkflowInstanceEntity instance = workflowInstanceRepo.findById(workflowInstanceId)
				.orElseThrow(() -> new RuntimeException("Workflow instance not found"));

		if (!instance.getStatus().equals("PENDING"))
			throw new RuntimeException("Already Processed");

		int currentLevel = instance.getCurrentLevel();
		int maxLevel = instance.getWorkflow().getApprovers().size();

		WorkflowInstanceHistoryEntity history = new WorkflowInstanceHistoryEntity();
		history.setWorkflowInstance(instance);
		history.setLevelNumber(currentLevel);
		history.setAction(isApproved ? "APPROVED" : "REJECTED");
		history.setApprover(principal.getuserId());
		history.setApproverName(principal.getLoginUser());
		history.setComment(comments);

		workflowInstanceHistoryRepo.save(history);

		if (currentLevel < maxLevel) {
			instance.setCurrentLevel(currentLevel + 1);
			instance.setStatus(isApproved ? "PENDING" : "REJECTED");
		} else {
			instance.setStatus(isApproved ? "APPROVED" : "REJECTED");
			instance.getPendingData().setStatus(isApproved ? "APPROVED" : "REJECTED");
		}

		workflowInstanceRepo.save(instance);

		return Arrays.asList(currentLevel, currentLevel + 1, maxLevel);

	}

	@GraphQLMutation
	@Override
	public boolean escalateRejectedWorkflow(Long instanceId, String comments) {

		WorkflowInstanceEntity instance = workflowInstanceRepo.findById(instanceId)
				.orElseThrow(() -> new RuntimeException("Workflow instance not found"));

		if (!instance.getStatus().equals("REJECTED"))
			throw new RuntimeException("Entity not eligible for escalation");

		WorkflowInstanceHistoryEntity history = new WorkflowInstanceHistoryEntity();
		history.setWorkflowInstance(instance);
		history.setLevelNumber(instance.getCurrentLevel());
		history.setAction("ESCALATED");
		history.setApprover(principal.getuserId());
		history.setApproverName(principal.getLoginUser());
		history.setComment(comments);

		workflowInstanceHistoryRepo.save(history);

		instance.setCurrentLevel(1); // restart workflow
		instance.setStatus("PENDING"); // back to pending
		instance.getPendingData().setStatus("PENDING");

		workflowInstanceRepo.save(instance);

		return true;

	}

}
