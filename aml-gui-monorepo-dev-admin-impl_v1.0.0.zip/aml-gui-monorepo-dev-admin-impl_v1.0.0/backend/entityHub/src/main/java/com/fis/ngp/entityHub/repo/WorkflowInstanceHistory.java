package com.fis.ngp.entityHub.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ngp.entityHub.entity.workflow.WorkflowInstanceHistoryEntity;

public interface WorkflowInstanceHistory extends JpaRepository<WorkflowInstanceHistoryEntity, Long> {

	List<WorkflowInstanceHistoryEntity> findByWorkflowInstanceEntityId(String entityId);

}
